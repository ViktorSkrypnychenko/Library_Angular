import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
    providedIn: 'root'
})
export class LibraryServiceService{
    constructor(private http: HttpClient) { }

    getAuthor(){
      return this.http.get('api/authors')
    }
    addAuthor( newSurname:any, newName:any, newBirth:any, newMiddlename?:any){
      return this.http.post('api/authors', {surname: newSurname, name:newName, birth:newBirth, middleName:newMiddlename})
    }
    editAuthor(author:any){
      return this.http.put(`api/authors/${author.id}`, {author})
    }
    deleteAuthor(id: any){
      return this.http.delete(`api/authors/${id}`)
    }

    getBooks(){
      return this.http.get('api/books')
    }
    addBook(mySurname:any, myName:any, myGenre:any, myPages:any){
       return this.http.post('api/books',{surname:mySurname, name:myName, genre:myGenre, pages:myPages} )
    }
    deleteBook(id:any){
      return this.http.delete(`api/books/${id}`)
    }
    editBook(book:any){
      return this.http.put(`api/books/${book.id}`,{book})
    }

    getGenre(){
      return this.http.get("api/genre")
    }
    addGenre(myGenre:any){
       return this.http.post('api/genre', {genre:myGenre})
    }
    deleteGenre(id:any){
       return this.http.delete(`api/genre/${id}`)
    }
}







