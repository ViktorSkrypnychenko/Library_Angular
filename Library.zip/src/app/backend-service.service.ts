import { getInterpolationArgsLength } from '@angular/compiler/src/render3/view/util';
import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable({
  providedIn: 'root'
})
export class BackendServiceService implements InMemoryDbService{

      constructor() { }

      createDb() {
        let authors = [
          { id: 1, surname: "Gogol", name:"Mykola", middleName: "Vasylovych", birth:"1809"}, 
          { id: 2, surname: "Shevchenko", name:"Taras",middleName: "Grygorovych", birth:"1814"},
          { id: 3, surname: "Doe", name:"Jhon",birth:"0001"}
        ];
        let books =  [
          {id:1, surname:"Gogol", name:"Vii", genre:"Horor", pages:"150"},
          {id:2, surname:"Gogol", name:"Taras Bulba", genre:"Action", pages:"250"},
          {id:3, surname:"Shevchenko", name:"Zapovit", genre:"Poem", pages:"350"},
          {id:4, surname:"Shevchenko", name:"Zapovit2", genre:"Poem", pages:"450"},
          {id:5, surname:"Doe", name:"Unknown", genre:"Drama",pages:"50"}
          ];
        let genre = [
          {id:1, genre:"Horor"},
          {id:2, genre:"Action"},
          {id:3, genre:"Poem"},
          {id:4, genre:"Drama"}
          ];  
          return { authors , books, genre }

      }
}

